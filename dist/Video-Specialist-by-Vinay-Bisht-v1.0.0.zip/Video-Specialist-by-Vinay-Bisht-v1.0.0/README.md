# Video Specialist by Vinay Bisht — Installer (Core · base tier · v1.0.0)

A portable installer for the **video-specialist-by-vinay-bisht** skill: paste a transcript, shot
notes or a description of your footage and get a ready-to-execute **Edit Sheet** — hook options,
cut list, caption script, on-screen text, reframe notes and a brand-consistency check — for any
editor. It plans; it never renders. It remembers *your* preferences, locally.

**Core package.** The skill is self-contained: no companion skills, no binaries, no models.
"Complete" means every file `SKILL.md` references is in this bundle.

## Contents

```
Video-Specialist-by-Vinay-Bisht-v1.0.0/
├── README.md              ← this file
├── manifest.json          ← machine-readable package metadata
├── install.sh             ← installer (interactive menu or flags; backs up before overwrite)
├── uninstall.sh           ← remover (leaves backups in place)
└── skill/
    └── video-specialist-by-vinay-bisht/
        ├── SKILL.md
        ├── README.md
        ├── templates/     brand-card.md · edit-sheet.md
        ├── references/    platform-specs.md · free-tool-setup.md · execute-in-your-tool.md
        ├── scripts/       check-tools.sh · check-tools.ps1   (detect only — never install)
        └── memory/        ships empty; fills on YOUR machine as you use the skill
```

## Install

### Agents with a filesystem (Claude Code, Codex CLI, any Agent-Skills tool)

Unzip, then from inside the folder:

```bash
chmod +x install.sh uninstall.sh      # zips can drop the executable bit
./install.sh                           # interactive menu
```

or with flags:

| Flag | Target | Path |
|---|---|---|
| `--user` | Claude Code, all your projects | `~/.claude/skills/` |
| `--project [DIR]` | Claude Code, one project | `DIR/.claude/skills/` (default `.`) |
| `--codex` | Codex CLI | `~/.codex/skills/` — *verify against your Codex version* |
| `--agents` | Generic agents | `~/.agents/skills/` |
| `--path DIR` | Anything else | `DIR/` |
| `--force` | Skip confirmations | — |

Manual fallback — copy the folder into your agent's skills directory:

```bash
cp -R skill/video-specialist-by-vinay-bisht ~/.claude/skills/
```

Then restart / reload the agent so it re-scans skills.

### Chat apps (no filesystem)

**Claude.ai — web or desktop**
1. Create a **Project**.
2. Paste the body of `skill/video-specialist-by-vinay-bisht/SKILL.md` into **Project instructions**.
3. Add every file under `templates/`, `references/` and `memory/README.md` as **Project knowledge**.

**ChatGPT — web or desktop (Project or Custom GPT)**
1. Create a **Project** (or a Custom GPT).
2. Paste the body of `SKILL.md` into the **Instructions** field.
3. Upload `templates/*`, `references/*` and `memory/README.md` as **Files / Knowledge**.

In chat apps the skill can't write `memory/`; at the end of a session it gives you a short
**Memory Card** to paste back next time. Same behaviour, you carry it.

## How it triggers

Say any of: *"edit this for Reels"* · *"cut this down to 45 seconds"* · *"write captions for this
clip"* · *"reframe this for LinkedIn"* · *"plan the edit"* · *"what should I cut"* — and paste
your transcript, shot notes or a description of the footage.

## Runtime dependencies — what is NOT bundled

**Nothing is required.** The skill is text-only and runs in any Claude or ChatGPT surface.

The tools below are the *user's* editor choices. The skill recommends one by device, links the
official download, and maps the Edit Sheet onto it — it never bundles or installs them.

| Tool | Why it isn't bundled | Get it |
|---|---|---|
| CapCut | Proprietary app, per-platform | https://www.capcut.com/ |
| DaVinci Resolve (free) | Proprietary, ~3 GB, registration required | https://www.blackmagicdesign.com/products/davinciresolve |
| ffmpeg | GPL/LGPL, ~100 MB per OS; users should get it from the source | https://ffmpeg.org/download.html |

`scripts/check-tools.sh` / `.ps1` only *detect* these and print the links.

## Verify · Uninstall

```bash
ls ~/.claude/skills/video-specialist-by-vinay-bisht/SKILL.md     # should exist
./uninstall.sh --user                                              # or --codex / --agents / --path DIR
```

Uninstall removes the skill folder **including its `memory/`** — copy that out first if you want
to keep your preferences. Backups from earlier installs (`*.backup.<timestamp>`) are left alone.

## Versioning · updates

Version lives in `manifest.json` and the `version:` line of `SKILL.md`. To update, run
`./install.sh` again with the same flag — the old copy is backed up automatically, so your
`memory/` folder is preserved in the backup; move it into the new install if you want it back.

---

Built by **Vinay Bisht** — brand storyteller & creative technologist.
Free to use and share with attribution. Not for resale.

**To build your first brand and creative system, email Vinay Bisht → vinbis9119@gmail.com**
