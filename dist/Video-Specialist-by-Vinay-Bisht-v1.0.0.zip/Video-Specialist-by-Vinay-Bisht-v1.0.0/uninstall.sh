#!/usr/bin/env bash
# uninstall.sh — Video Specialist by Vinay Bisht (base tier) v1.0.0
#
# Removes the installed skill folder. Backups (<name>.backup.*) are left in place on purpose.
# Your memory/ folder lives inside the skill — copy it out first if you want to keep it.
#
# Usage:
#   ./uninstall.sh                  interactive menu
#   ./uninstall.sh --user | --project [DIR] | --codex | --agents | --path DIR
#   ./uninstall.sh --force          skip confirmation
#   ./uninstall.sh -h | --help
set -euo pipefail
SKILL_NAME="video-specialist-by-vinay-bisht"
ok()   { printf "\033[32m✔\033[0m %s\n" "$1"; }
warn() { printf "\033[33m!\033[0m %s\n" "$1"; }
err()  { printf "\033[31m✘\033[0m %s\n" "$1" >&2; }
usage(){ sed -n '2,/^set -euo/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; }

TARGET=""; FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --user)    TARGET="$HOME/.claude/skills"; shift ;;
    --project) if [ "${2:-}" != "" ] && [ "${2#-}" = "$2" ]; then TARGET="$2/.claude/skills"; shift 2; else TARGET="./.claude/skills"; shift; fi ;;
    --codex)   TARGET="$HOME/.codex/skills"; shift ;;
    --agents)  TARGET="$HOME/.agents/skills"; shift ;;
    --path)    [ "${2:-}" != "" ] || { err "--path needs a directory"; exit 1; }; TARGET="$2"; shift 2 ;;
    --force)   FORCE=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) err "Unknown flag: $1"; usage; exit 1 ;;
  esac
done

if [ -z "$TARGET" ]; then
  echo "Video Specialist by Vinay Bisht — uninstall"
  echo "  1) ~/.claude/skills/   2) ./.claude/skills/   3) ~/.codex/skills/   4) ~/.agents/skills/   5) Custom"
  printf "Choose [1-5]: "; read -r choice
  case "$choice" in
    1) TARGET="$HOME/.claude/skills" ;; 2) TARGET="./.claude/skills" ;;
    3) TARGET="$HOME/.codex/skills" ;;  4) TARGET="$HOME/.agents/skills" ;;
    5) printf "Directory: "; read -r TARGET ;; *) err "Invalid choice"; exit 1 ;;
  esac
fi
TARGET="${TARGET/#\~/$HOME}"
DEST="$TARGET/$SKILL_NAME"

[ -d "$DEST" ] || { warn "Nothing installed at $DEST"; exit 0; }
if [ "$FORCE" -eq 0 ]; then
  printf "Remove %s ? (memory/ inside it will be deleted) [y/N] " "$DEST"; read -r yn
  [ "$yn" = "y" ] || [ "$yn" = "Y" ] || { warn "Aborted."; exit 0; }
fi
rm -rf "$DEST"
ok "Removed $DEST"
ls -d "$DEST".backup.* >/dev/null 2>&1 && warn "Backups left in place: $(ls -d "$DEST".backup.* | tr '\n' ' ')" || true
