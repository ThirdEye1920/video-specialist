#!/usr/bin/env bash
# install.sh — Video Specialist by Vinay Bisht (base tier) v1.0.0
#
# Installs the skill folder into an Agent-Skills directory. Non-destructive: an existing copy is
# moved to <name>.backup.<timestamp> before the new one is copied in. Verifies after install.
#
# Usage:
#   ./install.sh                  interactive menu
#   ./install.sh --user           Claude Code, user scope      → ~/.claude/skills/
#   ./install.sh --project [DIR]  Claude Code, project scope   → DIR/.claude/skills/  (DIR default: .)
#   ./install.sh --codex          Codex CLI, user scope        → ~/.codex/skills/
#   ./install.sh --agents         generic agents, user scope   → ~/.agents/skills/
#   ./install.sh --path DIR       any custom skills directory
#   ./install.sh --force          skip confirmations
#   ./install.sh -h | --help
#
# Claude.ai / ChatGPT chat apps have no filesystem — see README.md "Chat apps" for the manual steps.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_ROOT="$SCRIPT_DIR/skill"
SKILL_NAME="video-specialist-by-vinay-bisht"

ok()   { printf "\033[32m✔\033[0m %s\n" "$1"; }
warn() { printf "\033[33m!\033[0m %s\n" "$1"; }
err()  { printf "\033[31m✘\033[0m %s\n" "$1" >&2; }
usage(){ sed -n '2,/^set -euo/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; }

TARGET=""; FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --user)    TARGET="$HOME/.claude/skills"; shift ;;
    --project) if [ "${2:-}" != "" ] && [ "${2#-}" = "$2" ]; then TARGET="$2/.claude/skills"; shift 2; else TARGET="./.claude/skills"; shift; fi ;;
    --codex)   TARGET="$HOME/.codex/skills"; shift ;;
    --agents)  TARGET="$HOME/.agents/skills"; shift ;;
    --path)    [ "${2:-}" != "" ] || { err "--path needs a directory"; exit 1; }; TARGET="$2"; shift 2 ;;
    --force)   FORCE=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) err "Unknown flag: $1"; usage; exit 1 ;;
  esac
done

[ -d "$SRC_ROOT/$SKILL_NAME" ] || { err "Staged skill not found at $SRC_ROOT/$SKILL_NAME"; exit 1; }

if [ -z "$TARGET" ]; then
  echo "Video Specialist by Vinay Bisht — install"
  echo "  1) Claude Code, user       ~/.claude/skills/"
  echo "  2) Claude Code, project    ./.claude/skills/"
  echo "  3) Codex CLI, user         ~/.codex/skills/"
  echo "  4) Generic agents, user    ~/.agents/skills/"
  echo "  5) Custom directory"
  printf "Choose [1-5]: "; read -r choice
  case "$choice" in
    1) TARGET="$HOME/.claude/skills" ;;
    2) TARGET="./.claude/skills" ;;
    3) TARGET="$HOME/.codex/skills" ;;
    4) TARGET="$HOME/.agents/skills" ;;
    5) printf "Directory: "; read -r TARGET ;;
    *) err "Invalid choice"; exit 1 ;;
  esac
fi

TARGET="${TARGET/#\~/$HOME}"
mkdir -p "$TARGET"
DEST="$TARGET/$SKILL_NAME"

if [ -e "$DEST" ]; then
  BK="$DEST.backup.$(date +%Y%m%d-%H%M%S)"
  if [ "$FORCE" -eq 0 ]; then
    printf "%s exists. Back it up and replace? [y/N] " "$DEST"; read -r yn
    [ "$yn" = "y" ] || [ "$yn" = "Y" ] || { warn "Aborted."; exit 0; }
  fi
  mv "$DEST" "$BK"; ok "Backed up existing copy → $BK"
fi

cp -R "$SRC_ROOT/$SKILL_NAME" "$DEST"
chmod +x "$DEST/scripts/check-tools.sh" 2>/dev/null || true

# verify
if [ -f "$DEST/SKILL.md" ] && grep -q "^name: $SKILL_NAME" "$DEST/SKILL.md"; then
  ok "Installed $SKILL_NAME → $DEST  ($(find "$DEST" -type f | wc -l | tr -d ' ') files)"
else
  err "Verification failed: SKILL.md missing or name mismatch"; exit 1
fi

echo
echo "Next: restart or reload your agent so it re-scans skills, then say:"
echo "  \"edit this for Reels\"  and paste a transcript."
echo "No runtime dependencies. Free editor options are in references/free-tool-setup.md."
